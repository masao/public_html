#!/usr/local/bin/ruby
# $Id: yar.rb,v 1.2 2008/04/07 14:31:05 masao Exp $

class YahooArchive
   def initialize( yahoo_id )
      @yahoo_id = yahoo_id
   end
   def decode( io )
      bytes = io.read
      result = []
      while bytes.size > 0
         header = bytes.slice!(0, 4 * 4)
         t, unk, user, length = header.unpack("i4")
         time = Time.at(t)
         #p time
         #p user, unk, length
         content = bytes.slice!(0, length)
         #p content
         i = 0
         message = ""
         content.each_byte do |b|
            message << (@yahoo_id[i] ^ b)
            i += 1
            i = 0 if i >= @yahoo_id.size
         end
         mark, = bytes.slice!(0, 4).unpack("i")
         user = bytes.slice!(0, mark) unless mark == 0
         #p mark
         result << [ time, user, message ]
      end
      result
   end
end

if $0 == __FILE__
   yahooid = "tk_masao"
   ARGV.each do |f|
      yahooid = $1 if /^\d+-(\w+)$/ =~ File.basename(f, ".dat")
      decoder = YahooArchive.new(yahooid)
      decoder.decode(open(f)).each do |time, user, message|
         puts "#{time.strftime("%Y-%m-%d %H:%M")} [#{user}] #{message}"
         #puts message
      end
   end
end
